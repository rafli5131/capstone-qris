package com.legacy.qris;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import java.util.*;

@Service
public class QrisService {

 @Cacheable("inquiry")
 public Map<String,Object> process(String payload){
  Map<String,String> tlv = TLVParser.parse(payload);

  Map<String,Object> data = new HashMap<>();
  data.put("merchant_name", tlv.getOrDefault("59","UNKNOWN"));
  data.put("city", tlv.getOrDefault("60","UNKNOWN"));

  Map<String,Object> res = new HashMap<>();
  res.put("status","success");
  res.put("data",data);
  res.put("metadata", Map.of("latency_ms",50,"source","REDIS"));
  return res;
 }
}
