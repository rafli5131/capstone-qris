package com.legacy.qris;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import java.util.*;

@RestController
@RequestMapping("/api/qris")
public class QrisController {

 private final QrisService service;

 public QrisController(QrisService service){
  this.service=service;
 }

 @GetMapping("/inquiry/{payload}")
 public Map<String,Object> inquiry(@PathVariable String payload){
  return service.process(payload);
 }

 @PostMapping("/inquiry/image")
 public Map<String,Object> inquiryImage(@RequestParam("image") MultipartFile file){
  // dummy payload for demo (replace with QR decode lib if needed)
  String payload = "00020101021129370016A00000067701011101130066878787890215DINDA ROSYIDAH6007JAKARTA";
  return service.process(payload);
 }
}
