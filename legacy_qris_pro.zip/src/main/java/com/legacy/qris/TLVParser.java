package com.legacy.qris;
import java.util.*;

public class TLVParser {
 public static Map<String,String> parse(String payload){
  Map<String,String> map = new HashMap<>();
  int i=0;
  while(i<payload.length()){
   String tag = payload.substring(i,i+2);
   int len = Integer.parseInt(payload.substring(i+2,i+4));
   String value = payload.substring(i+4,i+4+len);
   map.put(tag,value);
   i += 4+len;
  }
  return map;
 }
}
