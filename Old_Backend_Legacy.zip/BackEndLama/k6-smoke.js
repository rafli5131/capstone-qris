import http from 'k6/http';
import { check, sleep } from 'k6';
import crypto from 'k6/crypto';

// =============================================
// Quick Smoke Test - Single Flow
// =============================================
const BASE_URL = __ENV.BASE_URL || 'http://localhost:8080';
const CLIENT_KEY = 'MK-9921-X';
const CLIENT_SECRET = 'secret_key_mk9921x_2026';
const QRIS_PAYLOAD = '00020101021126690021ID.CO.BANKMANDIRI.WWW01189360000801299399930211712993999340303UKE51440014ID.CO.QRIS.WWW0215ID10232756067300303UKE5204274153033605802ID5912M Ivan Store6015Jakarta Timur 61051364062070703A0163045F26';

export const options = {
    vus: 1,
    iterations: 1,
};

function generateSignature(payload) {
    return crypto.hmac('sha256', CLIENT_SECRET, payload, 'hex');
}

function getTimestamp() {
    return new Date().toISOString().replace(/\.\d{3}Z$/, 'Z');
}

export default function () {
    console.log('=== Step 1: QRIS Inquiry ===');
    const inquiryUrl = `${BASE_URL}/api/qris/inquiry/${encodeURIComponent(QRIS_PAYLOAD)}`;
    const inquiryUriPath = `/api/qris/inquiry/${encodeURIComponent(QRIS_PAYLOAD)}`;
    const inquiryTimestamp = getTimestamp();
    const inquirySignature = generateSignature(inquiryUriPath);

    const inquiryRes = http.get(inquiryUrl, {
        headers: {
            'X-Timestamp': inquiryTimestamp,
            'X-Client-Key': CLIENT_KEY,
            'X-Signature': inquirySignature,
        },
    });

    console.log(`  Status: ${inquiryRes.status}`);
    console.log(`  Body: ${inquiryRes.body}`);

    const inquiryOk = check(inquiryRes, {
        'inquiry returns 200': (r) => r.status === 200,
    });

    if (!inquiryOk) {
        console.error('Inquiry failed, stopping test');
        return;
    }

    const inquiryData = JSON.parse(inquiryRes.body);
    const inquiryId = inquiryData.data.inquiry_id;
    console.log(`  Inquiry ID: ${inquiryId}`);

    sleep(1);

    // Step 2: Payment
    console.log('\n=== Step 2: QRIS Payment ===');
    const paymentUrl = `${BASE_URL}/api/qris/payment`;
    const paymentBody = JSON.stringify({
        inquiry_id: inquiryId,
        user_id: 'user_123',
        amount: 1000,
        payment_method: 'balance',
        pincode: '******',
    });
    const paymentTimestamp = getTimestamp();
    const paymentSignature = generateSignature(paymentBody);

    const paymentRes = http.post(paymentUrl, paymentBody, {
        headers: {
            'X-Timestamp': paymentTimestamp,
            'X-Client-Key': CLIENT_KEY,
            'X-Signature': paymentSignature,
            'Content-Type': 'application/json',
        },
    });

    console.log(`  Status: ${paymentRes.status}`);
    console.log(`  Body: ${paymentRes.body}`);

    const paymentOk = check(paymentRes, {
        'payment returns 200': (r) => r.status === 200,
    });

    if (!paymentOk) {
        console.error('Payment failed, stopping test');
        return;
    }

    const paymentData = JSON.parse(paymentRes.body);
    const transactionId = paymentData.transaction_id;
    console.log(`  Transaction ID: ${transactionId}`);

    sleep(1);

    // Step 3: Transaction Status
    console.log('\n=== Step 3: Transaction Status ===');
    const statusUrl = `${BASE_URL}/api/transaction/status/${transactionId}`;
    const statusUriPath = `/api/transaction/status/${transactionId}`;
    const statusTimestamp = getTimestamp();
    const statusSignature = generateSignature(statusUriPath);

    const statusRes = http.get(statusUrl, {
        headers: {
            'X-Timestamp': statusTimestamp,
            'X-Client-Key': CLIENT_KEY,
            'X-Signature': statusSignature,
        },
    });

    console.log(`  Status: ${statusRes.status}`);
    console.log(`  Body: ${statusRes.body}`);

    check(statusRes, {
        'status returns 200': (r) => r.status === 200,
        'transaction is SUCCESS': (r) => {
            const body = JSON.parse(r.body);
            return body.status === 'SUCCESS';
        },
    });

    console.log('\n=== All Steps Completed ===');
}
