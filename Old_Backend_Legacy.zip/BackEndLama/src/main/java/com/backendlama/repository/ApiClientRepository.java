package com.backendlama.repository;

import com.backendlama.entity.ApiClient;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface ApiClientRepository extends JpaRepository<ApiClient, String> {
    Optional<ApiClient> findByClientId(String clientId);
}
