package com.backendlama.security;

import com.backendlama.entity.ApiClient;
import com.backendlama.repository.ApiClientRepository;
import jakarta.servlet.*;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Component;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Optional;

@Component
public class HmacAuthFilter implements Filter {

    private final ApiClientRepository apiClientRepository;

    public HmacAuthFilter(ApiClientRepository apiClientRepository) {
        this.apiClientRepository = apiClientRepository;
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {

        HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response;

        String path = httpRequest.getRequestURI();

        // Skip filter for non-API paths
        if (!path.startsWith("/api/")) {
            chain.doFilter(request, response);
            return;
        }

        String timestamp = httpRequest.getHeader("X-Timestamp");
        String clientKey = httpRequest.getHeader("X-Client-Key");
        String signature = httpRequest.getHeader("X-Signature");

        // Validate headers are present
        if (timestamp == null || clientKey == null || signature == null) {
            httpResponse.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            httpResponse.setContentType("application/json");
            httpResponse.getWriter().write(
                    "{\"status\":\"error\",\"message\":\"Missing required security headers (X-Timestamp, X-Client-Key, X-Signature)\"}");
            return;
        }

        // Lookup client
        Optional<ApiClient> clientOpt = apiClientRepository.findByClientId(clientKey);
        if (clientOpt.isEmpty()) {
            httpResponse.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            httpResponse.setContentType("application/json");
            httpResponse.getWriter().write(
                    "{\"status\":\"error\",\"message\":\"Invalid client key\"}");
            return;
        }

        ApiClient client = clientOpt.get();

        // Check client is active
        if (client.getStatus() != ApiClient.ClientStatus.ACTIVE) {
            httpResponse.setStatus(HttpServletResponse.SC_FORBIDDEN);
            httpResponse.setContentType("application/json");
            httpResponse.getWriter().write(
                    "{\"status\":\"error\",\"message\":\"Client is inactive\"}");
            return;
        }

        // Build payload for HMAC verification
        // For GET requests, use the URI path as payload
        // For POST requests, we need to read the body
        String payload;
        if ("GET".equalsIgnoreCase(httpRequest.getMethod())) {
            payload = httpRequest.getRequestURI();
        } else {
            // Wrap request to allow body re-reading
            CachedBodyHttpServletRequest cachedRequest = new CachedBodyHttpServletRequest(httpRequest);
            payload = new String(cachedRequest.getCachedBody(), StandardCharsets.UTF_8);

            // Verify HMAC signature
            String expectedSignature = calculateHmac(client.getClientSecret(), payload);
            if (!expectedSignature.equals(signature)) {
                httpResponse.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
                httpResponse.setContentType("application/json");
                httpResponse.getWriter().write(
                        "{\"status\":\"error\",\"message\":\"Invalid signature\"}");
                return;
            }

            chain.doFilter(cachedRequest, response);
            return;
        }

        // Verify HMAC signature for GET
        String expectedSignature = calculateHmac(client.getClientSecret(), payload);
        if (!expectedSignature.equals(signature)) {
            httpResponse.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            httpResponse.setContentType("application/json");
            httpResponse.getWriter().write(
                    "{\"status\":\"error\",\"message\":\"Invalid signature\"}");
            return;
        }

        chain.doFilter(request, response);
    }

    private String calculateHmac(String secretKey, String payload) {
        try {
            Mac mac = Mac.getInstance("HmacSHA256");
            SecretKeySpec keySpec = new SecretKeySpec(
                    secretKey.getBytes(StandardCharsets.UTF_8), "HmacSHA256");
            mac.init(keySpec);
            byte[] hmacBytes = mac.doFinal(payload.getBytes(StandardCharsets.UTF_8));

            // Convert to hex string
            StringBuilder hexString = new StringBuilder();
            for (byte b : hmacBytes) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) {
                    hexString.append('0');
                }
                hexString.append(hex);
            }
            return hexString.toString();
        } catch (Exception e) {
            throw new RuntimeException("Failed to calculate HMAC", e);
        }
    }
}
