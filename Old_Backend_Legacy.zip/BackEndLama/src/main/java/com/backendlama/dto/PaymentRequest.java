package com.backendlama.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PaymentRequest {

    @NotBlank
    @JsonProperty("inquiry_id")
    private String inquiryId;

    @NotBlank
    @JsonProperty("user_id")
    private String userId;

    @NotNull
    @Min(1)
    private Long amount;

    @NotBlank
    @JsonProperty("payment_method")
    private String paymentMethod;

    @NotBlank
    private String pincode;
}
