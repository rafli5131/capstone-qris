package com.backendlama.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class InquiryResponse {

    @JsonProperty("merchant_id")
    private String merchantId;

    @JsonProperty("merchant_name")
    private String merchantName;

    @JsonProperty("terminal_id")
    private String terminalId;

    private String city;

    @JsonProperty("fixed_amount")
    private int fixedAmount;

    @JsonProperty("inquiry_id")
    private String inquiryId;
}
