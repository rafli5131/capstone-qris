package com.backendlama.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PaymentResponse {

    private String status;

    @JsonProperty("transaction_id")
    private String transactionId;

    private String message;

    @JsonProperty("estimated_completion")
    private String estimatedCompletion;
}
