package com.backendlama.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TransactionStatusResponse {

    @JsonProperty("transaction_id")
    private String transactionId;

    private String status;

    @JsonProperty("final_balance")
    private Long finalBalance;

    private String timestamp;
}
