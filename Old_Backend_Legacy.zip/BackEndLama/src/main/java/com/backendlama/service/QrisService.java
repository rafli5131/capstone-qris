package com.backendlama.service;

import com.backendlama.dto.InquiryResponse;
import com.backendlama.dto.PaymentRequest;
import com.backendlama.dto.PaymentResponse;
import com.backendlama.entity.Account;
import com.backendlama.entity.Merchant;
import com.backendlama.entity.Transaction;
import com.backendlama.repository.AccountRepository;
import com.backendlama.repository.MerchantRepository;
import com.backendlama.repository.TransactionRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class QrisService {

    private final MerchantRepository merchantRepository;
    private final AccountRepository accountRepository;
    private final TransactionRepository transactionRepository;

    // In-memory store for inquiry data (no Redis)
    private final Map<String, InquiryData> inquiryStore = new ConcurrentHashMap<>();

    public QrisService(MerchantRepository merchantRepository,
            AccountRepository accountRepository,
            TransactionRepository transactionRepository) {
        this.merchantRepository = merchantRepository;
        this.accountRepository = accountRepository;
        this.transactionRepository = transactionRepository;
    }

    /**
     * Parse QRIS payload and lookup merchant from database (no caching).
     * Every call hits the database directly.
     */
    public InquiryResponse inquireQris(String qrisPayload) {
        // Simple QRIS payload parsing - extract merchant name and city from TLV
        String merchantName = extractTlvValue(qrisPayload, "59");
        String city = extractTlvValue(qrisPayload, "60");

        // Query ALL merchants from database every time (not optimal)
        List<Merchant> allMerchants = merchantRepository.findAll();

        // Find matching merchant by name (case-insensitive, partial match)
        Merchant merchant = null;
        for (Merchant m : allMerchants) {
            if (m.getIsActive() != null && m.getIsActive()) {
                if (merchantName != null && m.getMerchantName().toLowerCase()
                        .contains(merchantName.toLowerCase().trim())) {
                    merchant = m;
                    break;
                }
            }
        }

        // If no match found, use first active merchant as fallback
        if (merchant == null) {
            for (Merchant m : allMerchants) {
                if (m.getIsActive() != null && m.getIsActive()) {
                    merchant = m;
                    break;
                }
            }
        }

        if (merchant == null) {
            throw new RuntimeException("No active merchant found");
        }

        // Generate inquiry ID
        String inquiryId = "inq_" + UUID.randomUUID().toString().substring(0, 6);

        // Store inquiry data in memory
        inquiryStore.put(inquiryId, new InquiryData(
                merchant.getMerchantId(),
                merchant.getMerchantName(),
                merchant.getCity()));

        InquiryResponse response = new InquiryResponse();
        response.setMerchantId(merchant.getMerchantId());
        response.setMerchantName(merchant.getMerchantName());
        response.setTerminalId("T001");
        response.setCity(merchant.getCity());
        response.setFixedAmount(0);
        response.setInquiryId(inquiryId);

        return response;
    }

    /**
     * Process payment: validate inquiry, debit account, create transaction.
     * No optimization - synchronous processing.
     */
    @Transactional
    public PaymentResponse processPayment(PaymentRequest request) {
        // Validate inquiry exists
        InquiryData inquiry = inquiryStore.get(request.getInquiryId());
        if (inquiry == null) {
            throw new RuntimeException("Inquiry not found: " + request.getInquiryId());
        }

        // Lookup account (user)
        Account account = accountRepository.findById(request.getUserId())
                .orElseThrow(() -> new RuntimeException("Account not found: " + request.getUserId()));

        BigDecimal amount = BigDecimal.valueOf(request.getAmount());

        // Check sufficient balance
        if (account.getBalance().compareTo(amount) < 0) {
            throw new RuntimeException("Insufficient balance");
        }

        // Debit account
        account.setBalance(account.getBalance().subtract(amount));
        accountRepository.save(account);

        // Create transaction record
        String transactionId = UUID.randomUUID().toString();
        String traceId = "trace_" + UUID.randomUUID().toString().substring(0, 8);

        Transaction transaction = new Transaction();
        transaction.setTransactionId(transactionId);
        transaction.setTraceId(traceId);
        transaction.setAccountId(request.getUserId());
        transaction.setMerchantId(inquiry.merchantId);
        transaction.setAmount(amount);
        transaction.setStatus(Transaction.TransactionStatus.PENDING);
        transaction.setCreatedAt(LocalDateTime.now());
        transactionRepository.save(transaction);

        // Simulate processing - update to SUCCESS directly (no async)
        transaction.setStatus(Transaction.TransactionStatus.SUCCESS);
        transactionRepository.save(transaction);

        // Remove used inquiry
        inquiryStore.remove(request.getInquiryId());

        PaymentResponse response = new PaymentResponse();
        response.setStatus("processing");
        response.setTransactionId(transactionId);
        response.setMessage("Transaksi sedang diproses");
        response.setEstimatedCompletion("200ms");

        return response;
    }

    /**
     * Simple TLV parser for QRIS payload.
     * TLV format: 2-digit tag + 2-digit length + value
     */
    private String extractTlvValue(String payload, String targetTag) {
        try {
            int i = 0;
            while (i < payload.length() - 4) {
                String tag = payload.substring(i, i + 2);
                int length = Integer.parseInt(payload.substring(i + 2, i + 4));
                String value = payload.substring(i + 4, i + 4 + length);

                if (tag.equals(targetTag)) {
                    return value;
                }

                i = i + 4 + length;
            }
        } catch (Exception e) {
            // Parsing failed, return null
        }
        return null;
    }

    // Simple data holder for inquiry
    private record InquiryData(String merchantId, String merchantName, String city) {
    }
}
