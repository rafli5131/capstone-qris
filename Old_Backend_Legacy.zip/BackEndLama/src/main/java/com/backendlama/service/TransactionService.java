package com.backendlama.service;

import com.backendlama.dto.TransactionStatusResponse;
import com.backendlama.entity.Account;
import com.backendlama.entity.Transaction;
import com.backendlama.repository.AccountRepository;
import com.backendlama.repository.TransactionRepository;
import org.springframework.stereotype.Service;

import java.time.format.DateTimeFormatter;

@Service
public class TransactionService {

    private final TransactionRepository transactionRepository;
    private final AccountRepository accountRepository;

    public TransactionService(TransactionRepository transactionRepository,
            AccountRepository accountRepository) {
        this.transactionRepository = transactionRepository;
        this.accountRepository = accountRepository;
    }

    /**
     * Get transaction status by transaction ID.
     * No caching - hits database directly every time.
     */
    public TransactionStatusResponse getTransactionStatus(String transactionId) {
        Transaction transaction = transactionRepository.findByTransactionId(transactionId)
                .orElseThrow(() -> new RuntimeException("Transaction not found: " + transactionId));

        // Lookup current balance
        Account account = accountRepository.findById(transaction.getAccountId())
                .orElse(null);

        Long finalBalance = null;
        if (account != null) {
            finalBalance = account.getBalance().longValue();
        }

        TransactionStatusResponse response = new TransactionStatusResponse();
        response.setTransactionId(transaction.getTransactionId());
        response.setStatus(transaction.getStatus().name());
        response.setFinalBalance(finalBalance);
        response.setTimestamp(transaction.getCreatedAt() != null
                ? transaction.getCreatedAt().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME) + "Z"
                : null);

        return response;
    }
}
