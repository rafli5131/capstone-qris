package com.backendlama.controller;

import com.backendlama.dto.TransactionStatusResponse;
import com.backendlama.service.TransactionService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/transaction")
public class TransactionController {

    private final TransactionService transactionService;

    public TransactionController(TransactionService transactionService) {
        this.transactionService = transactionService;
    }

    /**
     * GET /api/transaction/status/{transaction_id}
     * Get transaction status - hits database directly every time.
     */
    @GetMapping("/status/{transaction_id}")
    public ResponseEntity<TransactionStatusResponse> getStatus(
            @PathVariable("transaction_id") String transactionId) {

        TransactionStatusResponse response = transactionService.getTransactionStatus(transactionId);
        return ResponseEntity.ok(response);
    }
}
