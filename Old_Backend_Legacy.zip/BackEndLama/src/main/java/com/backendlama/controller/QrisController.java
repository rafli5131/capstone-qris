package com.backendlama.controller;

import com.backendlama.dto.ApiResponse;
import com.backendlama.dto.InquiryResponse;
import com.backendlama.dto.PaymentRequest;
import com.backendlama.dto.PaymentResponse;
import com.backendlama.service.QrisService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/qris")
public class QrisController {

    private final QrisService qrisService;

    public QrisController(QrisService qrisService) {
        this.qrisService = qrisService;
    }

    /**
     * GET /api/qris/inquiry/{qris_payload}
     * Query merchant info from QRIS payload - hits database directly (no Redis).
     */
    @GetMapping("/inquiry/{qris_payload}")
    public ResponseEntity<ApiResponse<InquiryResponse>> inquiry(
            @PathVariable("qris_payload") String qrisPayload) {

        long startTime = System.currentTimeMillis();

        InquiryResponse data = qrisService.inquireQris(qrisPayload);

        long latency = System.currentTimeMillis() - startTime;
        ApiResponse<InquiryResponse> response = ApiResponse.success(data, latency, "database");

        return ResponseEntity.ok(response);
    }

    /**
     * POST /api/qris/payment
     * Process QRIS payment.
     */
    @PostMapping("/payment")
    public ResponseEntity<PaymentResponse> payment(@Valid @RequestBody PaymentRequest request) {
        PaymentResponse response = qrisService.processPayment(request);
        return ResponseEntity.ok(response);
    }
}
