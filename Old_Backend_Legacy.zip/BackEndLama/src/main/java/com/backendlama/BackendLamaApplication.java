package com.backendlama;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackendLamaApplication {

    public static void main(String[] args) {
        SpringApplication.run(BackendLamaApplication.class, args);
    }
}
