package com.backendlama.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Table(name = "api_clients")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ApiClient {

    @Id
    @Column(name = "client_id", nullable = false)
    private String clientId;

    @Column(name = "client_secret", nullable = false)
    private String clientSecret;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false)
    private ClientStatus status;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    public enum ClientStatus {
        ACTIVE, INACTIVE
    }
}
