-- =============================================
-- Seed Data for QRIS Payment API
-- =============================================

-- API Clients (for HMAC authentication)
INSERT INTO api_clients (client_id, client_secret, status, created_at)
VALUES ('MK-9921-X', 'secret_key_mk9921x_2026', 'ACTIVE', '2026-01-01 00:00:00')
ON CONFLICT (client_id) DO NOTHING;

INSERT INTO api_clients (client_id, client_secret, status, created_at)
VALUES ('Mobile-App-01', 'secret_mobile_app_01', 'ACTIVE', '2026-01-15 00:00:00')
ON CONFLICT (client_id) DO NOTHING;

INSERT INTO api_clients (client_id, client_secret, status, created_at)
VALUES ('WEB-POS-01', 'secret_web_pos_01', 'INACTIVE', '2026-02-01 00:00:00')
ON CONFLICT (client_id) DO NOTHING;

-- Merchants (1000 records via generate_series)
INSERT INTO merchants (merchant_id, merchant_name, mcc, city, is_active)
SELECT
    'MICH-' || LPAD(s::TEXT, 4, '0'),
    (ARRAY[
        'Toko Berkah', 'Warung Sejahtera', 'Apotek Sehat', 'Restoran Padang', 'Kopi Nusantara',
        'Swalayan Makmur', 'Toko Elektronik', 'Bengkel Jaya', 'Salon Cantik', 'Bakso Malang',
        'Martabak Pecenongan', 'Ayam Geprek', 'Toko Bangunan', 'Optik Tunggal', 'Fotokopi Cepat',
        'Laundry Bersih', 'Pet Shop Lucu', 'Toko Buku Ilmu', 'Depot Air Minum', 'Toko Kue Lezat',
        'Mie Ayam Ceker', 'Soto Lamongan', 'Bubur Ayam Enak', 'Nasi Goreng Kambing', 'Es Teler 77',
        'Kantin Sekolah', 'Toko Obat Murah', 'Warung Kopi', 'Toko Roti Manis', 'Sate Madura',
        'Rumah Makan Sederhana', 'Toko Perhiasan', 'Toko Sepatu', 'Toko Tas Branded', 'Warung Nasi',
        'Kedai Susu', 'Toko Plastik', 'Toko Cat Warna', 'Cuci Mobil Kilat', 'Pangkas Rambut',
        'Studio Foto', 'Toko Mainan Anak', 'Toko Oleh Oleh', 'Toko Batik Keris', 'Toko Emas Murni',
        'M Ivan Store', 'Indomaret', 'Alfamart', 'Toko Serba Ada', 'Minimarket Barokah'
    ])[(s % 50) + 1] || ' ' || LPAD(s::TEXT, 4, '0'),
    (ARRAY[
        '2741','4111','4121','4131','5111','5211','5311','5411','5499','5541',
        '5812','5813','5912','5921','5942','5944','5945','5947','5999','7011'
    ])[(s % 20) + 1],
    (ARRAY[
        'Jakarta Pusat', 'Jakarta Timur', 'Jakarta Barat', 'Jakarta Selatan', 'Jakarta Utara',
        'Bandung', 'Surabaya', 'Malang', 'Semarang', 'Yogyakarta',
        'Medan', 'Makassar', 'Palembang', 'Denpasar', 'Balikpapan',
        'Manado', 'Pontianak', 'Banjarmasin', 'Padang', 'Pekanbaru',
        'Solo', 'Bogor', 'Depok', 'Tangerang', 'Bekasi'
    ])[(s % 25) + 1],
    (s % 10 != 0)
FROM generate_series(1, 1000) AS s
ON CONFLICT (merchant_id) DO NOTHING;

-- Accounts (simulating core banking)
INSERT INTO accounts (account_id, balance, currency, version)
VALUES ('user_123', 500000.00, 'IDR', 0)
ON CONFLICT (account_id) DO NOTHING;

INSERT INTO accounts (account_id, balance, currency, version)
VALUES ('user_456', 1500000.00, 'IDR', 0)
ON CONFLICT (account_id) DO NOTHING;

INSERT INTO accounts (account_id, balance, currency, version)
VALUES ('user_789', 250000.00, 'IDR', 0)
ON CONFLICT (account_id) DO NOTHING;
