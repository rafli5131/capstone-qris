import http from 'k6/http';
import { check, sleep, group } from 'k6';
import { SharedArray } from 'k6/data';
import crypto from 'k6/crypto';

// =============================================
// Configuration
// =============================================
const BASE_URL = __ENV.BASE_URL || 'http://localhost:8080';
const CLIENT_KEY = 'MK-9921-X';
const CLIENT_SECRET = 'secret_key_mk9921x_2026';

const QRIS_PAYLOAD = '00020101021126690021ID.CO.BANKMANDIRI.WWW01189360000801299399930211712993999340303UKE51440014ID.CO.QRIS.WWW0215ID10232756067300303UKE5204274153033605802ID5912M Ivan Store6015Jakarta Timur 61051364062070703A0163045F26';

// =============================================
// K6 Options
// =============================================
export const options = {
    scenarios: {
        // Scenario 1: Smoke test
        smoke_test: {
            executor: 'constant-vus',
            vus: 1,
            duration: '10s',
            tags: { scenario: 'smoke' },
        },

        // Scenario 2: Load test
        load_test: {
            executor: 'ramping-vus',
            startVUs: 0,
            stages: [
                { duration: '10s', target: 10 },   // ramp up
                { duration: '30s', target: 10 },   // sustain
                { duration: '10s', target: 50 },   // spike
                { duration: '20s', target: 50 },   // sustain spike
                { duration: '10s', target: 0 },    // ramp down
            ],
            startTime: '15s',
            tags: { scenario: 'load' },
        },

        // Scenario 3: Stress test
        stress_test: {
            executor: 'ramping-vus',
            startVUs: 0,
            stages: [
                { duration: '10s', target: 1000 },
                { duration: '30s', target: 1000 },
                { duration: '10s', target: 0 },
            ],
            startTime: '100s',
            tags: { scenario: 'stress' },
        },
    },

    thresholds: {
        http_req_duration: ['p(95)<2000'],    // 95% request < 2s
        http_req_failed: ['rate<0.1'],         // error rate < 10%
        'http_req_duration{endpoint:inquiry}': ['p(95)<3000'],
        'http_req_duration{endpoint:payment}': ['p(95)<3000'],
        'http_req_duration{endpoint:status}': ['p(95)<2000'],
    },
};

// =============================================
// HMAC-SHA256 Signature Helper
// =============================================
function generateSignature(payload) {
    const hmac = crypto.hmac('sha256', CLIENT_SECRET, payload, 'hex');
    return hmac;
}

function getTimestamp() {
    return new Date().toISOString().replace(/\.\d{3}Z$/, 'Z');
}

function getAuthHeaders(payload) {
    const timestamp = getTimestamp();
    const signature = generateSignature(payload);
    return {
        'X-Timestamp': timestamp,
        'X-Client-Key': CLIENT_KEY,
        'X-Signature': signature,
        'Content-Type': 'application/json',
    };
}

// =============================================
// Test Functions
// =============================================

/**
 * Test 1: QRIS Inquiry
 */
function testInquiry() {
    const url = `${BASE_URL}/api/qris/inquiry/${encodeURIComponent(QRIS_PAYLOAD)}`;
    const uriPath = `/api/qris/inquiry/${encodeURIComponent(QRIS_PAYLOAD)}`;
    const headers = getAuthHeaders(uriPath);

    const res = http.get(url, {
        headers: headers,
        tags: { endpoint: 'inquiry' },
    });

    const success = check(res, {
        'inquiry: status 200': (r) => r.status === 200,
        'inquiry: has merchant_id': (r) => {
            try {
                const body = JSON.parse(r.body);
                return body.data && body.data.merchant_id !== undefined;
            } catch (e) {
                return false;
            }
        },
        'inquiry: has inquiry_id': (r) => {
            try {
                const body = JSON.parse(r.body);
                return body.data && body.data.inquiry_id !== undefined;
            } catch (e) {
                return false;
            }
        },
        'inquiry: status is success': (r) => {
            try {
                const body = JSON.parse(r.body);
                return body.status === 'success';
            } catch (e) {
                return false;
            }
        },
    });

    if (res.status === 200) {
        try {
            const body = JSON.parse(res.body);
            return body.data ? body.data.inquiry_id : null;
        } catch (e) {
            return null;
        }
    }
    return null;
}

/**
 * Test 2: QRIS Payment
 */
function testPayment(inquiryId) {
    const url = `${BASE_URL}/api/qris/payment`;

    const payload = JSON.stringify({
        inquiry_id: inquiryId,
        user_id: 'user_123',
        amount: 1000,
        payment_method: 'balance',
        pincode: '******',
    });

    const headers = getAuthHeaders(payload);

    const res = http.post(url, payload, {
        headers: headers,
        tags: { endpoint: 'payment' },
    });

    const success = check(res, {
        'payment: status 200': (r) => r.status === 200,
        'payment: has transaction_id': (r) => {
            try {
                const body = JSON.parse(r.body);
                return body.transaction_id !== undefined;
            } catch (e) {
                return false;
            }
        },
        'payment: status is processing': (r) => {
            try {
                const body = JSON.parse(r.body);
                return body.status === 'processing';
            } catch (e) {
                return false;
            }
        },
    });

    if (res.status === 200) {
        try {
            const body = JSON.parse(res.body);
            return body.transaction_id || null;
        } catch (e) {
            return null;
        }
    }
    return null;
}

/**
 * Test 3: Transaction Status
 */
function testTransactionStatus(transactionId) {
    const url = `${BASE_URL}/api/transaction/status/${transactionId}`;
    const uriPath = `/api/transaction/status/${transactionId}`;
    const headers = getAuthHeaders(uriPath);

    const res = http.get(url, {
        headers: headers,
        tags: { endpoint: 'status' },
    });

    check(res, {
        'status: status 200': (r) => r.status === 200,
        'status: has transaction_id': (r) => {
            try {
                const body = JSON.parse(r.body);
                return body.transaction_id !== undefined;
            } catch (e) {
                return false;
            }
        },
        'status: transaction SUCCESS': (r) => {
            try {
                const body = JSON.parse(r.body);
                return body.status === 'SUCCESS';
            } catch (e) {
                return false;
            }
        },
    });
}

// =============================================
// Main Test Flow
// =============================================
export default function () {
    group('Full QRIS Payment Flow', () => {

        // Step 1: Inquiry
        const inquiryId = testInquiry();
        sleep(0.5);

        if (inquiryId) {
            // Step 2: Payment
            const transactionId = testPayment(inquiryId);
            sleep(0.5);

            if (transactionId) {
                // Step 3: Check Transaction Status
                testTransactionStatus(transactionId);
            }
        } else {
            // If inquiry fails, still test with dummy data for load
            console.warn('Inquiry failed, skipping payment and status');
        }

        sleep(1);
    });
}

// =============================================
// Summary Handler
// =============================================
export function handleSummary(data) {
    const summary = {
        'Total Requests': data.metrics.http_reqs ? data.metrics.http_reqs.values.count : 0,
        'Failed Requests': data.metrics.http_req_failed ? data.metrics.http_req_failed.values.passes : 0,
        'Avg Duration (ms)': data.metrics.http_req_duration ? data.metrics.http_req_duration.values.avg.toFixed(2) : 0,
        'P95 Duration (ms)': data.metrics.http_req_duration ? data.metrics.http_req_duration.values['p(95)'].toFixed(2) : 0,
        'P99 Duration (ms)': data.metrics.http_req_duration ? data.metrics.http_req_duration.values['p(99)'].toFixed(2) : 0,
    };

    console.log('\n========================================');
    console.log('  QRIS Payment API - K6 Test Summary');
    console.log('========================================');
    for (const [key, value] of Object.entries(summary)) {
        console.log(`  ${key}: ${value}`);
    }
    console.log('========================================\n');

    return {
        'stdout': textSummary(data, { indent: '  ', enableColors: true }),
        'k6-summary.json': JSON.stringify(data, null, 2),
    };
}

import { textSummary } from 'https://jslib.k6.io/k6-summary/0.0.2/index.js';
